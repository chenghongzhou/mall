<template>
    <div class="main">
        <div class="top">
            <i class="top_close" @click="forbidBack()"></i>
            确认兑换
        </div>
        <!-- <div class="header">
            <div class="go_back" @click="forbidBack()"></div>
        </div> -->
        <div class="address_box">
            <div class="address_icon" v-if="list.length >0"></div>
            <div class="address_info" v-if="list.length >0">
                <div class="address_info_name">{{defaultDate.name}}  {{defaultDate.tel}}</div>
                <div class="address_info_address">{{defaultDate.address}} {{defaultDate.address_detail}}</div>
            </div>
            <div class="address_info" v-if="list.length == 0">
               
                <div class="address_info_name" style="margin-top:0.4rem;color:#cccccc"> 您还没有收获地址，去添加</div>
            </div>
            <div class="address_list" @click="goAddress()"></div>
            <div class="go_edit_address"></div>
        </div>

        <div class="buy_good_box">
            <div class="order_info_box">
                <img :src="goodInfo.pic" alt="" class="order_good_img">
                <div class="order_info">
                    <div class="order_name">{{goodInfo.name}}</div>
                    <div class="good_intr">{{goodInfo.name_dec}}</div>
                    <div class="good_price"><i class="money_icon"></i>{{goodInfo.is_give_integral}}<span>+￥{{goodInfo.current_price}}</span></div>
                </div>
            </div>
            <div class="order_money_box">
                <div class="order_money">
                    <div class="order_money_in">兑换数量<div class="nums"><div class="reduce" @click="goodNum(1)"></div><div class="buy_nums">{{num}}</div><div class="add" @click="goodNum(2)"></div></div></div>
                    
                </div>
            </div>
        </div>

        <div class="footer">
            <div class="money_box">
                <div class="intergral">合计(积分)：<i></i><span>{{total_integral}}</span></div>
                <div class="money">合计(现金)：<i></i><font>￥</font><span>{{total_price}}</span></div>
            </div>
            <div class="btn" @click="successMask = true">立即兑换</div>
        </div>

        <div class="mask" v-if="successMask">
			<div class="mask_main success">
				<div class="box tanchuscale">
                    <div class="success_title">兑换成功</div>
                    <div class="success_msg">继续赚取积分，兑换更多好礼</div>
                    <div class="success_btn" @click="successMask = false">确定</div>
				</div>
			</div>
		</div>
        <div class="mask" v-if="fileMask">
			<div class="mask_main file">
				<div class="box tanchuscale">
                    <div class="file_title">兑换成功</div>
                    <div class="file_need">本次兑换共需999积分</div>
                    <div class="file_you">当前积分99</div>
                    <div class="file_btn" @click="goTaskWall()">立即赚积分</div>
                    <div class="file_close" @click="fileMask = false"></div>
				</div>
			</div>
		</div>
    </div>
</template>

<script>
import store from '../../../vuex/store';
export default {
    data(){
        return {
            num: 1,
            successMask: false,
            fileMask: false,
            goodInfo:{},
            total_integral:'',  //总共的积分
            total_price:'',    //总共的价格
            userInfoData:{},
            list:[],
            defaultDate:{},
        }
    },
    methods: {
        goodNum(index){
            //1减 2加
            if(index == 1){
                this.num>1?this.num = this.num-1:this.num=1;
            }else{
                this.num++; 
            };
            this.total_integral = this.goodInfo.is_give_integral*this.num;
            this.total_price = this.goodInfo.current_price*this.num;
        },
        //获取地址
        getAddress(){
            var _this = this;
            var openid = _this.userInfoData.open_id;
            var addressInfo = {
                'store_id': 1001,
                "open_id":openid
            };
            store.dispatch('GetAddress', addressInfo)
                .then((res) => {
                    if(res) {
                        _this.list = res.data;
                        if(_this.list.length > 0){
                          _this.list.forEach((item,index) => {
                             if(item.if_default){
                                 _this.defaultDate = item;
                             }
                          });
                          if(!_this.defaultDate.if_default){
                            _this.defaultDate=_this.list[0];
                          };
                        }
                    } else {
                        
                    }
                })
                .catch((err) => {
                    console.log(err);
                });
        },
        goAddress(){
            this.$router.replace({path:'/addressManagement/index'});
        },
        goTaskWall(){
            this.$router.replace({path:'/taskWall'});
        },
        forbidBack(){
            this.$router.replace({path:'/goodDetail'});
        }
    },
    destroyed(){
        window.removeEventListener('popstate', this.forbidBack, false);
    },
    mounted(){
        var _this = this;
        config.isGoBack(_this.forbidBack);
        _this.$nextTick(() =>{
            var t_data = config.getCookie('userInfoData');
            if(t_data){
                _this.userInfoData = JSON.parse(config.getCookie('userInfoData'));
            };
             _this.goodInfo = _this.$store.state.goodInfo;
             _this.total_integral = _this.goodInfo.is_give_integral;
             _this.total_price = _this.goodInfo.current_price;
             
             
            _this.getAddress();
        })
    }
}
</script>

<style scoped>
@import './index.css';
</style>