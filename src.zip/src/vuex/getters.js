const getters = {
    address: state => state.address,
    goodInfo: state => state.goodInfo,
};
export default getters;